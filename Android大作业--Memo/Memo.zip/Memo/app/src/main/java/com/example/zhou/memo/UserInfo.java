package com.example.zhou.memo;

/**
 * Created by zhou on 2016/12/13.
 */

public class UserInfo {
    private String datetime;
    private String content;
    private String alerttime;

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String date) {
        this.datetime = date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAlerttime() {
        return alerttime;
    }

    public void setAlerttime(String alerttime) {
        this.alerttime = alerttime;
    }

}

